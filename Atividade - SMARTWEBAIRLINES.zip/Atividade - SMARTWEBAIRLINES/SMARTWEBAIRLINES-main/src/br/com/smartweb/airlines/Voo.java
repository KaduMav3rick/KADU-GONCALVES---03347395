package br.com.smartweb.airlines;

public record Voo(String codigo, String origem, String destino) {
} 
