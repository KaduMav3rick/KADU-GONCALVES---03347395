# SMARTWEBAIRLINES

Aplicação desenvolida com Java 8 e apresenta a mensagem de erro:

======================== SMARTWEB AIRLINES ========================

Exception in thread "main" java.util.NoSuchElementException: No value present
	at java.base/java.util.Optional.get(Optional.java:143)
	at br.com.smartweb.airlines.ServicoDeBagagem.contratar(ServicoDeBagagem.java:22)
	at br.com.smartweb.airlines.AirLinesMain.main(AirLinesMain.java:15)

 Seguiremos na implementação das boas práticas com 'Optional' para aprimorar e evoluir a aplicação.
